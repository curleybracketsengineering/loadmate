<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title></title>
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="2685.4">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; font: 12.0px Helvetica}
    p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; font: 12.0px Helvetica; min-height: 14.0px}
  </style>
</head>
<body>
<p class="p1">import { StyleSheet, Text, View } from 'react-native';</p>
<p class="p1">import { AlertTriangle } from 'lucide-react-native';</p>
<p class="p1">import { useCaravan } from '@/contexts/CaravanContext';</p>
<p class="p2"><br></p>
<p class="p1">export default function WeightCard() {</p>
<p class="p1"><span class="Apple-converted-space">  </span>const {<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">    </span>config,<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">    </span>currentWeight,<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">    </span>availableWeight,<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">    </span>weightPercentage,<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">    </span>noseWeightImpact,</p>
<p class="p1"><span class="Apple-converted-space">    </span>calculatedNoseWeight,</p>
<p class="p1"><span class="Apple-converted-space">    </span>towBallWeightMin,<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">    </span>towBallWeightMax,<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">    </span>isTowBallWeightSafe<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">  </span>} = useCaravan();</p>
<p class="p2"><br></p>
<p class="p1"><span class="Apple-converted-space">  </span>const getStatusColor = () =&gt; {</p>
<p class="p1"><span class="Apple-converted-space">    </span>if (weightPercentage &gt;= 100) return '#dc2626';</p>
<p class="p1"><span class="Apple-converted-space">    </span>if (weightPercentage &gt;= 90) return '#f59e0b';</p>
<p class="p1"><span class="Apple-converted-space">    </span>return '#10b981';</p>
<p class="p1"><span class="Apple-converted-space">  </span>};</p>
<p class="p2"><br></p>
<p class="p1"><span class="Apple-converted-space">  </span>const getStatusText = () =&gt; {</p>
<p class="p1"><span class="Apple-converted-space">    </span>if (weightPercentage &gt;= 100) return 'OVERWEIGHT';</p>
<p class="p1"><span class="Apple-converted-space">    </span>if (weightPercentage &gt;= 90) return 'NEAR LIMIT';</p>
<p class="p1"><span class="Apple-converted-space">    </span>return 'SAFE';</p>
<p class="p1"><span class="Apple-converted-space">  </span>};</p>
<p class="p2"><br></p>
<p class="p1"><span class="Apple-converted-space">  </span>return (</p>
<p class="p1"><span class="Apple-converted-space">    </span>&lt;View style={styles.container}&gt;</p>
<p class="p1"><span class="Apple-converted-space">      </span>&lt;View style={[styles.statusBadge, { backgroundColor: getStatusColor() }]}&gt;</p>
<p class="p1"><span class="Apple-converted-space">        </span>{weightPercentage &gt;= 90 &amp;&amp; &lt;AlertTriangle size={20} color="#fff" /&gt;}</p>
<p class="p1"><span class="Apple-converted-space">        </span>&lt;Text style={styles.statusText}&gt;{getStatusText()}&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">      </span>&lt;/View&gt;</p>
<p class="p2"><br></p>
<p class="p1"><span class="Apple-converted-space">      </span>&lt;View style={styles.weightCard}&gt;</p>
<p class="p1"><span class="Apple-converted-space">        </span>&lt;View style={styles.weightDisplay}&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;View style={styles.weightRow}&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;Text style={styles.weightLabel}&gt;Current Weight&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;Text style={[styles.weightValue, { color: getStatusColor() }]}&gt;{currentWeight.toFixed(1)} kg&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;View style={styles.progressBar}&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">              </span>style={[</p>
<p class="p1"><span class="Apple-converted-space">                </span>styles.progressFill,<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">                </span>{ width: `${Math.min(weightPercentage, 100)}%`, backgroundColor: getStatusColor() }</p>
<p class="p1"><span class="Apple-converted-space">              </span>]}<span class="Apple-converted-space"> </span></p>
<p class="p1"><span class="Apple-converted-space">            </span>/&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;View style={styles.weightRow}&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;Text style={styles.weightSubLabel}&gt;MTPLM: {config.mtplm} kg&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;Text style={[styles.weightSubLabel, { color: availableWeight &lt; 0 ? '#dc2626' : '#10b981' }]}&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>{availableWeight &gt;= 0 ? 'Available' : 'Over'}: {Math.abs(availableWeight).toFixed(1)} kg</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">        </span>&lt;/View&gt;</p>
<p class="p2"><br></p>
<p class="p1"><span class="Apple-converted-space">        </span>&lt;View style={styles.divider} /&gt;</p>
<p class="p2"><br></p>
<p class="p1"><span class="Apple-converted-space">        </span>&lt;View style={styles.towBallSection}&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;Text style={styles.towBallTitle}&gt;Nose Weight&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;View style={styles.noseWeightCard}&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={styles.noseWeightRow}&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.noseWeightLabel}&gt;Base (6%)&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.noseWeightValue}&gt;{(currentWeight * 0.06).toFixed(1)} kg&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={styles.noseWeightRow}&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.noseWeightLabel}&gt;Location Impact&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={[styles.noseWeightValue, { color: noseWeightImpact &gt;= 0 ? '#10b981' : '#dc2626' }]}&gt;</p>
<p class="p1"><span class="Apple-converted-space">                </span>{noseWeightImpact &gt;= 0 ? '+' : ''}{noseWeightImpact.toFixed(1)} kg</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={styles.divider} /&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={styles.noseWeightRow}&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.noseWeightLabelBold}&gt;Calculated Nose Weight&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.noseWeightValueLarge}&gt;{calculatedNoseWeight.toFixed(1)} kg&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;View style={styles.towBallRange}&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={styles.towBallRangeItem}&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.towBallRangeLabel}&gt;Min (5%)&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.towBallRangeValue}&gt;{towBallWeightMin.toFixed(1)} kg&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={styles.towBallRangeDivider} /&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={styles.towBallRangeItem}&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.towBallRangeLabel}&gt;Max (7%)&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={styles.towBallRangeValue}&gt;{towBallWeightMax.toFixed(1)} kg&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>{config.carMaxTowBallWeight &gt; 0 &amp;&amp; (</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;View style={[styles.carMaxInfo, !isTowBallWeightSafe &amp;&amp; styles.carMaxInfoWarning]}&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;Text style={[styles.carMaxLabel, !isTowBallWeightSafe &amp;&amp; styles.carMaxLabelWarning]}&gt;</p>
<p class="p1"><span class="Apple-converted-space">                </span>Car Max Tow Ball: {config.carMaxTowBallWeight} kg</p>
<p class="p1"><span class="Apple-converted-space">              </span>&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>{!isTowBallWeightSafe &amp;&amp; (</p>
<p class="p1"><span class="Apple-converted-space">                </span>&lt;View style={styles.warningBadge}&gt;</p>
<p class="p1"><span class="Apple-converted-space">                  </span>&lt;AlertTriangle size={16} color="#fff" /&gt;</p>
<p class="p1"><span class="Apple-converted-space">                  </span>&lt;Text style={styles.warningText}&gt;EXCEEDS CAR LIMIT&lt;/Text&gt;</p>
<p class="p1"><span class="Apple-converted-space">                </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">              </span>)}</p>
<p class="p1"><span class="Apple-converted-space">            </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">          </span>)}</p>
<p class="p1"><span class="Apple-converted-space">        </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">      </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">    </span>&lt;/View&gt;</p>
<p class="p1"><span class="Apple-converted-space">  </span>);</p>
<p class="p1">}</p>
<p class="p2"><br></p>
<p class="p1">const styles = StyleSheet.create({</p>
<p class="p1"><span class="Apple-converted-space">  </span>container: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 16,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>statusBadge: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>flexDirection: 'row',</p>
<p class="p1"><span class="Apple-converted-space">    </span>alignItems: 'center',</p>
<p class="p1"><span class="Apple-converted-space">    </span>justifyContent: 'center',</p>
<p class="p1"><span class="Apple-converted-space">    </span>padding: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 8,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>statusText: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#fff',</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 18,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '700' as const,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>weightCard: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#fff',</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 16,</p>
<p class="p1"><span class="Apple-converted-space">    </span>padding: 20,</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 16,</p>
<p class="p1"><span class="Apple-converted-space">    </span>boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',</p>
<p class="p1"><span class="Apple-converted-space">    </span>elevation: 4,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>weightDisplay: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 12,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>divider: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>height: 1,</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#e2e8f0',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>towBallSection: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 12,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>towBallTitle: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 16,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '600' as const,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#1e293b',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>towBallRange: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>flexDirection: 'row',</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#f8fafc',</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>padding: 16,</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 16,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>towBallRangeItem: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>flex: 1,</p>
<p class="p1"><span class="Apple-converted-space">    </span>alignItems: 'center',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>towBallRangeDivider: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>width: 1,</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#e2e8f0',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>towBallRangeLabel: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#64748b',</p>
<p class="p1"><span class="Apple-converted-space">    </span>marginBottom: 4,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>towBallRangeValue: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 20,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '700' as const,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#2563eb',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>carMaxInfo: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#f0f9ff',</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 8,</p>
<p class="p1"><span class="Apple-converted-space">    </span>padding: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 8,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>carMaxInfoWarning: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#fef2f2',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>carMaxLabel: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 14,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '600' as const,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#1e40af',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>carMaxLabelWarning: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#991b1b',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>warningBadge: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>flexDirection: 'row',</p>
<p class="p1"><span class="Apple-converted-space">    </span>alignItems: 'center',</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#dc2626',</p>
<p class="p1"><span class="Apple-converted-space">    </span>padding: 8,</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 6,</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 6,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>warningText: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#fff',</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '700' as const,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>weightRow: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>flexDirection: 'row',</p>
<p class="p1"><span class="Apple-converted-space">    </span>justifyContent: 'space-between',</p>
<p class="p1"><span class="Apple-converted-space">    </span>alignItems: 'center',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>weightLabel: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 16,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#64748b',</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '600' as const,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>weightValue: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 32,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '700' as const,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>weightSubLabel: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 14,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#64748b',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>progressBar: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>height: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#e2e8f0',</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 6,</p>
<p class="p1"><span class="Apple-converted-space">    </span>overflow: 'hidden',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>progressFill: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>height: '100%',</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 6,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>noseWeightCard: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>backgroundColor: '#f8fafc',</p>
<p class="p1"><span class="Apple-converted-space">    </span>borderRadius: 12,</p>
<p class="p1"><span class="Apple-converted-space">    </span>padding: 16,</p>
<p class="p1"><span class="Apple-converted-space">    </span>gap: 8,</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>noseWeightRow: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>flexDirection: 'row',</p>
<p class="p1"><span class="Apple-converted-space">    </span>justifyContent: 'space-between',</p>
<p class="p1"><span class="Apple-converted-space">    </span>alignItems: 'center',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>noseWeightLabel: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 14,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#64748b',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>noseWeightLabelBold: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 14,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '700' as const,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#1e293b',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>noseWeightValue: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 16,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '600' as const,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#1e293b',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1"><span class="Apple-converted-space">  </span>noseWeightValueLarge: {</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontSize: 24,</p>
<p class="p1"><span class="Apple-converted-space">    </span>fontWeight: '700' as const,</p>
<p class="p1"><span class="Apple-converted-space">    </span>color: '#2563eb',</p>
<p class="p1"><span class="Apple-converted-space">  </span>},</p>
<p class="p1">});</p>
</body>
</html>
