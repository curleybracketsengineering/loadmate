# mobile-app (React Native scaffold)

This is a lightweight scaffold for a mobile React codebase so you can paste/copy files from your **Rork** project one at a time.

## Folder layout

- `src/contexts/` - app state providers (e.g. `CaravanContext`)
- `src/components/` - reusable UI blocks
- `src/screens/` - screen-level components
- `src/theme/` - colors/styles helpers
- `src/utils/` - small shared helpers

## Copying files from Rork

When you copy a file, paste it into the closest matching folder:

- A file that uses `useSomething()` and provides data via context -> `src/contexts/`
- A `export default function ...()` that renders UI -> `src/components/`
- A screen-level component (often used by navigation) -> `src/screens/`

If your copied file imports `@/....`, this scaffold includes a `tsconfig.json` path alias mapping `@/` to `src/`.

## Notes

- This scaffold focuses on structure (so imports and conventions line up). To run it, you’ll still need to use whatever React Native / Expo tooling you prefer (e.g. Expo).
- This scaffold includes an Expo Router layout at `src/app/_layout.tsx`.
- Your initial route is `src/app/index.tsx` (it renders `src/screens/HomeScreen.tsx`).

