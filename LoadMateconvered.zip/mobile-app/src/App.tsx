// Expo Router entry point.
// In a real Expo Router app, you typically set `main` to `expo-router/entry` in package.json.
// This file is kept only to avoid confusion if your setup expects an `App.tsx`.
import 'expo-router/entry';

export default function App() {
  return null;
}

