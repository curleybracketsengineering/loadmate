export const colors = {
  bg: '#0f172a',
  card: '#0b1220',
  text: '#e2e8f0',
  muted: '#94a3b8',
  danger: '#dc2626',
  warning: '#f59e0b',
  success: '#10b981',
  primary: '#2563eb',
} as const;

