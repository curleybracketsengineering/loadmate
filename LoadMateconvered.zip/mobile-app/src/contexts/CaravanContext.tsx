import React, { createContext, useContext, useMemo, useState } from 'react';

export type CaravanConfig = {
  mtplm: number;
  carMaxTowBallWeight: number;
};

export type CaravanContextValue = {
  config: CaravanConfig;
  currentWeight: number;
  availableWeight: number;
  weightPercentage: number;
  noseWeightImpact: number;
  calculatedNoseWeight: number;
  towBallWeightMin: number;
  towBallWeightMax: number;
  isTowBallWeightSafe: boolean;
};

const CaravanContext = createContext<CaravanContextValue | null>(null);

/**
 * Provider slot so pasted components can call `useCaravan()`.
 *
 * When you copy real logic from Rork, replace the dummy state below.
 */
export function CaravanProvider({ children }: { children: React.ReactNode }) {
  const [config] = useState<CaravanConfig>({
    mtplm: 3500,
    carMaxTowBallWeight: 120,
  });

  // Dummy values so UI compiles before you paste real calculation logic.
  const value: CaravanContextValue = useMemo(
    () => ({
      config,
      currentWeight: 850,
      availableWeight: 75,
      weightPercentage: 85,
      noseWeightImpact: 12.3,
      calculatedNoseWeight: 51.4,
      towBallWeightMin: 40,
      towBallWeightMax: 56,
      isTowBallWeightSafe: true,
    }),
    [config],
  );

  return <CaravanContext.Provider value={value}>{children}</CaravanContext.Provider>;
}

export function useCaravan() {
  const ctx = useContext(CaravanContext);
  if (!ctx) {
    throw new Error('useCaravan must be used within <CaravanProvider />');
  }
  return ctx;
}

