import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';

export function HomeScreen() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Mobile scaffold ready</Text>
        <Text style={styles.subtitle}>
          Copy your Rork files into `src/screens/`, `src/components/`, and `src/contexts/`.
        </Text>
        <Text style={styles.tip}>
          If an imported file uses `@/..`, the alias is already set up in `mobile-app/tsconfig.json`.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    gap: 12,
  },
  card: {
    backgroundColor: '#0b1220',
    borderRadius: 16,
    padding: 16,
    gap: 8,
  },
  title: {
    color: '#e2e8f0',
    fontSize: 20,
    fontWeight: '800',
  },
  subtitle: {
    color: '#cbd5e1',
    fontSize: 14,
    lineHeight: 20,
  },
  tip: {
    color: '#94a3b8',
    fontSize: 12,
    lineHeight: 18,
  },
});

