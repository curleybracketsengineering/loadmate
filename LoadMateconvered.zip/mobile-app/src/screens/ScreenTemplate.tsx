import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

/**
 * Paste screen-level components here (the stuff navigation usually renders).
 * Prefer `export function X()` or `export default function X()` to match the copied file.
 */
export default function ScreenTemplate() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Screen template</Text>
      <Text style={styles.body}>Replace this with your copied screen component.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#0f172a',
  },
  title: {
    color: '#e2e8f0',
    fontSize: 18,
    fontWeight: '700',
  },
  body: {
    marginTop: 8,
    color: '#cbd5e1',
  },
});

