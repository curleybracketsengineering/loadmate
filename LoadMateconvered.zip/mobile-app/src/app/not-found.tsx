import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

export default function NotFound() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Page not found</Text>
      <Text style={styles.body}>This route doesn’t exist in your Expo Router app.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
    backgroundColor: '#0f172a',
    gap: 8,
  },
  title: {
    color: '#e2e8f0',
    fontSize: 20,
    fontWeight: '800',
  },
  body: {
    color: '#94a3b8',
    fontSize: 14,
    lineHeight: 20,
  },
});

