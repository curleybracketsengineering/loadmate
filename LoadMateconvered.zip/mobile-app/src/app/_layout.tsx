import React from 'react';
import { Stack } from 'expo-router';

import { CaravanProvider } from '@/contexts/CaravanContext';

export default function RootLayout() {
  return (
    <CaravanProvider>
      <Stack screenOptions={{ headerShown: false }} />
    </CaravanProvider>
  );
}

