import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

/**
 * Paste `WeightCard` (or whatever similar component you have) into `src/components/`.
 *
 * The Rork `WeightCard` you mentioned uses `useCaravan()`; see `src/contexts/CaravanContext.tsx`.
 */
export default function WeightCard() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>WeightCard slot</Text>
      <Text style={styles.body}>
        Paste your Rork `WeightCard` implementation here.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 16,
    padding: 16,
    backgroundColor: '#0b1220',
    gap: 8,
  },
  title: {
    color: '#e2e8f0',
    fontSize: 16,
    fontWeight: '800',
  },
  body: {
    color: '#94a3b8',
    fontSize: 12,
    lineHeight: 18,
  },
});

