import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

/**
 * Paste reusable UI components here.
 * If your copied file expects props, define them at the top of this file or keep
 * the same interface from the original Rork code.
 */
export default function ComponentTemplate() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Component template</Text>
      <Text style={styles.body}>Paste component code into this folder.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    backgroundColor: '#0b1220',
    padding: 12,
    gap: 6,
  },
  title: {
    color: '#e2e8f0',
    fontWeight: '800',
  },
  body: {
    color: '#94a3b8',
    fontSize: 12,
    lineHeight: 18,
  },
});

