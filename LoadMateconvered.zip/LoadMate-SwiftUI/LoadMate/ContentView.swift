import SwiftUI

struct ContentView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Summary", systemImage: "gauge.with.dots.needle.bottom.50percent")
                }
            
            LoadView()
                .tabItem {
                    Label("Load", systemImage: "shippingbox")
                }
            
            LibraryView()
                .tabItem {
                    Label("Library", systemImage: "books.vertical")
                }
            
            SetupView()
                .tabItem {
                    Label("Setup", systemImage: "gearshape")
                }
        }
        .tint(Theme.Colors.primary)
    }
}

#Preview {
    ContentView()
        .environmentObject(CaravanManager())
}

