import SwiftUI

/// Theme constants ported from React Native mobile-app/src/theme/colors.ts
enum Theme {
    enum Colors {
        /// Main background color: #0f172a
        static let background = Color(hex: "0f172a")
        
        /// Card background color: #0b1220
        static let card = Color(hex: "0b1220")
        
        /// Primary text color: #e2e8f0
        static let text = Color(hex: "e2e8f0")
        
        /// Secondary/muted text color: #94a3b8
        static let muted = Color(hex: "94a3b8")
        
        /// Danger/error color: #dc2626
        static let danger = Color(hex: "dc2626")
        
        /// Warning color: #f59e0b
        static let warning = Color(hex: "f59e0b")
        
        /// Success color: #10b981
        static let success = Color(hex: "10b981")
        
        /// Primary accent color: #2563eb
        static let primary = Color(hex: "2563eb")
        
        /// White card background for light sections
        static let cardWhite = Color.white
        
        /// Light gray background: #f8fafc
        static let lightBackground = Color(hex: "f8fafc")
        
        /// Dark text for light backgrounds: #1e293b
        static let textDark = Color(hex: "1e293b")
        
        /// Secondary dark text: #64748b
        static let textSecondary = Color(hex: "64748b")
        
        /// Info blue: #1e40af
        static let info = Color(hex: "1e40af")
    }
    
    enum Spacing {
        static let xs: CGFloat = 4
        static let sm: CGFloat = 8
        static let md: CGFloat = 12
        static let lg: CGFloat = 16
        static let xl: CGFloat = 20
        static let xxl: CGFloat = 24
    }
    
    enum CornerRadius {
        static let sm: CGFloat = 8
        static let md: CGFloat = 12
        static let lg: CGFloat = 16
    }
}

// MARK: - Color Extension for Hex Support
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

