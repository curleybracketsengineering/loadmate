import Foundation
import SwiftUI
import Combine

/// Main state manager replacing React's CaravanContext
/// Provides all weight calculations and manages loaded items
@MainActor
class CaravanManager: ObservableObject {
    
    // MARK: - Published Properties
    
    @Published var config: CaravanConfig {
        didSet { saveConfig() }
    }
    
    @Published var libraryItems: [Item] {
        didSet { saveLibraryItems() }
    }
    
    @Published var loadedItems: [LoadedItem] {
        didSet { saveLoadedItems() }
    }
    
    // MARK: - Computed Properties (matching React CaravanContextValue)
    
    /// Total weight of all loaded items
    var loadedWeight: Double {
        loadedItems.reduce(0) { $0 + $1.totalWeight }
    }
    
    /// Current total weight = base weight + loaded items
    var currentWeight: Double {
        config.baseWeight + loadedWeight
    }
    
    /// Available weight remaining before hitting MTPLM
    var availableWeight: Double {
        config.mtplm - currentWeight
    }
    
    /// Percentage of MTPLM used
    var weightPercentage: Double {
        guard config.mtplm > 0 else { return 0 }
        return (currentWeight / config.mtplm) * 100
    }
    
    /// Weight status based on percentage
    var weightStatus: WeightStatus {
        if weightPercentage >= 100 { return .overweight }
        if weightPercentage >= 90 { return .nearLimit }
        return .safe
    }
    
    /// Nose weight impact from item locations
    var noseWeightImpact: Double {
        loadedItems.reduce(0) { total, loadedItem in
            let factor = config.factor(for: loadedItem.zone)
            return total + (loadedItem.totalWeight * factor)
        }
    }
    
    /// Base nose weight (6% of current weight)
    var baseNoseWeight: Double {
        currentWeight * config.baseNoseWeightPercentage
    }
    
    /// Calculated nose weight = base + impact from locations
    var calculatedNoseWeight: Double {
        baseNoseWeight + noseWeightImpact
    }
    
    /// Minimum recommended tow ball weight (5% of current weight)
    var towBallWeightMin: Double {
        currentWeight * config.minNoseWeightPercentage
    }
    
    /// Maximum recommended tow ball weight (7% of current weight)
    var towBallWeightMax: Double {
        currentWeight * config.maxNoseWeightPercentage
    }
    
    /// Whether nose weight is within safe range AND below car limit
    var isTowBallWeightSafe: Bool {
        guard config.carMaxTowBallWeight > 0 else { return true }
        return calculatedNoseWeight <= config.carMaxTowBallWeight
    }
    
    /// Whether nose weight is within recommended percentage range
    var isNoseWeightInRange: Bool {
        calculatedNoseWeight >= towBallWeightMin && calculatedNoseWeight <= towBallWeightMax
    }
    
    // MARK: - Initialization
    
    init() {
        self.config = Self.loadConfig()
        self.libraryItems = Self.loadLibraryItems()
        self.loadedItems = Self.loadLoadedItems()
    }
    
    // MARK: - Library Item Management
    
    func addItem(_ item: Item) {
        libraryItems.append(item)
    }
    
    func updateItem(_ item: Item) {
        if let index = libraryItems.firstIndex(where: { $0.id == item.id }) {
            libraryItems[index] = item
        }
    }
    
    func deleteItem(_ item: Item) {
        libraryItems.removeAll { $0.id == item.id }
        // Also remove from loaded items
        loadedItems.removeAll { $0.item.id == item.id }
    }

    // MARK: - Load/Unload Management

    func loadItem(_ item: Item, quantity: Int = 1, zone: LocationZone? = nil) {
        let targetZone = zone ?? item.defaultZone ?? .middle

        // Check if item is already loaded in same zone
        if let index = loadedItems.firstIndex(where: { $0.item.id == item.id && $0.zone == targetZone }) {
            loadedItems[index].quantity += quantity
        } else {
            let loadedItem = LoadedItem(item: item, quantity: quantity, zone: targetZone)
            loadedItems.append(loadedItem)
        }
    }

    func unloadItem(_ loadedItem: LoadedItem) {
        loadedItems.removeAll { $0.id == loadedItem.id }
    }

    func updateLoadedItemZone(_ loadedItem: LoadedItem, to zone: LocationZone) {
        if let index = loadedItems.firstIndex(where: { $0.id == loadedItem.id }) {
            loadedItems[index].zone = zone
        }
    }

    func updateLoadedItemQuantity(_ loadedItem: LoadedItem, quantity: Int) {
        if let index = loadedItems.firstIndex(where: { $0.id == loadedItem.id }) {
            if quantity <= 0 {
                loadedItems.remove(at: index)
            } else {
                loadedItems[index].quantity = quantity
            }
        }
    }

    func isItemLoaded(_ item: Item) -> Bool {
        loadedItems.contains { $0.item.id == item.id }
    }

    func loadedQuantity(for item: Item) -> Int {
        loadedItems.filter { $0.item.id == item.id }.reduce(0) { $0 + $1.quantity }
    }

    // MARK: - Persistence

    private static let configKey = "CaravanConfig"
    private static let libraryKey = "LibraryItems"
    private static let loadedKey = "LoadedItems"

    private func saveConfig() {
        if let data = try? JSONEncoder().encode(config) {
            UserDefaults.standard.set(data, forKey: Self.configKey)
        }
    }

    private static func loadConfig() -> CaravanConfig {
        guard let data = UserDefaults.standard.data(forKey: configKey),
              let config = try? JSONDecoder().decode(CaravanConfig.self, from: data) else {
            return CaravanConfig()
        }
        return config
    }

    private func saveLibraryItems() {
        if let data = try? JSONEncoder().encode(libraryItems) {
            UserDefaults.standard.set(data, forKey: Self.libraryKey)
        }
    }

    private static func loadLibraryItems() -> [Item] {
        guard let data = UserDefaults.standard.data(forKey: libraryKey),
              let items = try? JSONDecoder().decode([Item].self, from: data) else {
            return Self.sampleItems
        }
        return items
    }

    private func saveLoadedItems() {
        if let data = try? JSONEncoder().encode(loadedItems) {
            UserDefaults.standard.set(data, forKey: Self.loadedKey)
        }
    }

    private static func loadLoadedItems() -> [LoadedItem] {
        guard let data = UserDefaults.standard.data(forKey: loadedKey),
              let items = try? JSONDecoder().decode([LoadedItem].self, from: data) else {
            return []
        }
        return items
    }

    // MARK: - Sample Data

    private static var sampleItems: [Item] {
        [
            Item(name: "Awning", weight: 15, defaultZone: .front, category: .camping),
            Item(name: "Camping Chairs (x2)", weight: 8, defaultZone: .rear, category: .camping),
            Item(name: "Cool Box", weight: 5, defaultZone: .middle, category: .kitchen),
            Item(name: "Bedding Set", weight: 6, defaultZone: .middle, category: .bedding),
            Item(name: "Water Container (20L)", weight: 20, defaultZone: .middle, category: .water),
            Item(name: "BBQ", weight: 12, defaultZone: .bikeRack, category: .kitchen),
            Item(name: "Toolkit", weight: 4, defaultZone: .frontLocker, category: .tools),
        ]
    }
}

// MARK: - Weight Status Enum

enum WeightStatus {
    case safe
    case nearLimit
    case overweight

    var color: Color {
        switch self {
        case .safe: return Theme.Colors.success
        case .nearLimit: return Theme.Colors.warning
        case .overweight: return Theme.Colors.danger
        }
    }

    var text: String {
        switch self {
        case .safe: return "SAFE"
        case .nearLimit: return "NEAR LIMIT"
        case .overweight: return "OVERWEIGHT"
        }
    }

    var showWarningIcon: Bool {
        self != .safe
    }
}

