import SwiftUI

@main
struct LoadMateApp: App {
    @StateObject private var caravanManager = CaravanManager()
    @AppStorage("hasAcceptedDisclaimer") private var hasAcceptedDisclaimer = false
    
    var body: some Scene {
        WindowGroup {
            if hasAcceptedDisclaimer {
                ContentView()
                    .environmentObject(caravanManager)
            } else {
                DisclaimerView(hasAcceptedDisclaimer: $hasAcceptedDisclaimer)
            }
        }
    }
}

