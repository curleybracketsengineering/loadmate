import Foundation

/// Represents an item in the library that can be loaded into the caravan
struct Item: Identifiable, Codable, Hashable {
    var id: UUID
    var name: String
    var weight: Double // in kg
    var defaultZone: LocationZone?
    var category: ItemCategory?
    
    init(
        id: UUID = UUID(),
        name: String,
        weight: Double,
        defaultZone: LocationZone? = nil,
        category: ItemCategory? = nil
    ) {
        self.id = id
        self.name = name
        self.weight = weight
        self.defaultZone = defaultZone
        self.category = category
    }
}

/// Categories for organizing items
enum ItemCategory: String, CaseIterable, Codable, Identifiable {
    case camping = "Camping"
    case kitchen = "Kitchen"
    case bedding = "Bedding"
    case leisure = "Leisure"
    case tools = "Tools"
    case water = "Water"
    case clothes = "Clothes"
    case other = "Other"
    
    var id: String { rawValue }
    
    var icon: String {
        switch self {
        case .camping: return "tent"
        case .kitchen: return "fork.knife"
        case .bedding: return "bed.double"
        case .leisure: return "gamecontroller"
        case .tools: return "wrench.and.screwdriver"
        case .water: return "drop"
        case .clothes: return "tshirt"
        case .other: return "shippingbox"
        }
    }
}

/// Represents an item that has been loaded into the caravan
struct LoadedItem: Identifiable, Codable, Hashable {
    var id: UUID
    var item: Item
    var quantity: Int
    var zone: LocationZone
    
    init(
        id: UUID = UUID(),
        item: Item,
        quantity: Int = 1,
        zone: LocationZone
    ) {
        self.id = id
        self.item = item
        self.quantity = quantity
        self.zone = zone
    }
    
    /// Total weight of this loaded item (weight × quantity)
    var totalWeight: Double {
        item.weight * Double(quantity)
    }
}

