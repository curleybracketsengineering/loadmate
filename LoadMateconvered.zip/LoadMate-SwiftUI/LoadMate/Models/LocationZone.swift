import Foundation

/// Represents the 5 loading zones in the caravan
/// Each zone has a weight impact factor affecting nose weight calculation
enum LocationZone: String, CaseIterable, Codable, Identifiable {
    case frontLocker = "Front Locker"
    case front = "Front"
    case middle = "Middle (Axle)"
    case rear = "Rear"
    case bikeRack = "Bike Rack"
    
    var id: String { rawValue }
    
    /// Default impact factors for nose weight calculation
    /// Positive values increase nose weight, negative values decrease it
    var defaultFactor: Double {
        switch self {
        case .frontLocker: return 0.25
        case .front: return 0.15
        case .middle: return 0.0
        case .rear: return -0.20
        case .bikeRack: return -0.35
        }
    }
    
    /// SF Symbol icon for display
    var icon: String {
        switch self {
        case .frontLocker: return "archivebox"
        case .front: return "arrow.up.circle"
        case .middle: return "circle.dotted"
        case .rear: return "arrow.down.circle"
        case .bikeRack: return "bicycle"
        }
    }
    
    /// Short display name
    var shortName: String {
        switch self {
        case .frontLocker: return "F.Locker"
        case .front: return "Front"
        case .middle: return "Middle"
        case .rear: return "Rear"
        case .bikeRack: return "Bike Rack"
        }
    }
}

