import Foundation

/// Configuration for the caravan setup
/// Ported from React Native CaravanContext.tsx
struct CaravanConfig: Codable {
    /// Base weight of the caravan (measured empty weight)
    var baseWeight: Double
    
    /// Maximum Technically Permissible Laden Mass
    var mtplm: Double
    
    /// Maximum tow ball weight the car can handle
    var carMaxTowBallWeight: Double
    
    /// Custom zone factors (user can override defaults)
    var zoneFactors: [LocationZone: Double]
    
    /// Base nose weight percentage (typically around 6%)
    var baseNoseWeightPercentage: Double
    
    /// Minimum safe nose weight percentage (typically 5%)
    var minNoseWeightPercentage: Double
    
    /// Maximum safe nose weight percentage (typically 7%)
    var maxNoseWeightPercentage: Double
    
    init(
        baseWeight: Double = 0,
        mtplm: Double = 1500,
        carMaxTowBallWeight: Double = 100,
        zoneFactors: [LocationZone: Double]? = nil,
        baseNoseWeightPercentage: Double = 0.06,
        minNoseWeightPercentage: Double = 0.05,
        maxNoseWeightPercentage: Double = 0.07
    ) {
        self.baseWeight = baseWeight
        self.mtplm = mtplm
        self.carMaxTowBallWeight = carMaxTowBallWeight
        self.baseNoseWeightPercentage = baseNoseWeightPercentage
        self.minNoseWeightPercentage = minNoseWeightPercentage
        self.maxNoseWeightPercentage = maxNoseWeightPercentage
        
        // Use provided factors or defaults
        if let factors = zoneFactors {
            self.zoneFactors = factors
        } else {
            self.zoneFactors = Dictionary(
                uniqueKeysWithValues: LocationZone.allCases.map { ($0, $0.defaultFactor) }
            )
        }
    }
    
    /// Get the factor for a specific zone
    func factor(for zone: LocationZone) -> Double {
        zoneFactors[zone] ?? zone.defaultFactor
    }
}

