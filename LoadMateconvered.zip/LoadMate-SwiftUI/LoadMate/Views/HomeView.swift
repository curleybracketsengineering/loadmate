import SwiftUI

/// Main summary screen showing weight status and nose weight calculations
/// Ported from React Native HomeScreen
struct HomeView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: Theme.Spacing.lg) {
                    // Weight Card
                    WeightCardView()
                    
                    // Quick Stats
                    QuickStatsView()
                    
                    // Loaded Items Summary
                    if !caravanManager.loadedItems.isEmpty {
                        LoadedItemsSummaryView()
                    }
                }
                .padding()
            }
            .background(Theme.Colors.background)
            .navigationTitle("LoadMate")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(Theme.Colors.background, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
        }
    }
}

// MARK: - Quick Stats View

struct QuickStatsView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    
    var body: some View {
        HStack(spacing: Theme.Spacing.md) {
            StatCard(
                title: "Items Loaded",
                value: "\(caravanManager.loadedItems.count)",
                icon: "shippingbox.fill",
                color: Theme.Colors.primary
            )
            
            StatCard(
                title: "Load Weight",
                value: String(format: "%.1f kg", caravanManager.loadedWeight),
                icon: "scalemass.fill",
                color: Theme.Colors.success
            )
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: Theme.Spacing.sm) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(color)
                Spacer()
            }
            
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundStyle(Theme.Colors.text)
            
            Text(title)
                .font(.caption)
                .foregroundStyle(Theme.Colors.muted)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.Colors.card)
        .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))
    }
}

// MARK: - Loaded Items Summary View

struct LoadedItemsSummaryView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    
    var body: some View {
        VStack(alignment: .leading, spacing: Theme.Spacing.md) {
            Text("Loaded Items")
                .font(.headline)
                .foregroundStyle(Theme.Colors.text)
            
            VStack(spacing: Theme.Spacing.sm) {
                ForEach(caravanManager.loadedItems.prefix(5)) { loadedItem in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(loadedItem.item.name)
                                .font(.subheadline)
                                .foregroundStyle(Theme.Colors.text)
                            Text(loadedItem.zone.shortName)
                                .font(.caption)
                                .foregroundStyle(Theme.Colors.muted)
                        }
                        
                        Spacer()
                        
                        Text("×\(loadedItem.quantity)")
                            .font(.caption)
                            .foregroundStyle(Theme.Colors.muted)
                        
                        Text(String(format: "%.1f kg", loadedItem.totalWeight))
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundStyle(Theme.Colors.text)
                            .frame(width: 70, alignment: .trailing)
                    }
                    .padding(.vertical, Theme.Spacing.xs)
                }
                
                if caravanManager.loadedItems.count > 5 {
                    Text("+ \(caravanManager.loadedItems.count - 5) more items")
                        .font(.caption)
                        .foregroundStyle(Theme.Colors.muted)
                }
            }
            .padding()
            .background(Theme.Colors.card)
            .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))
        }
    }
}

#Preview {
    HomeView()
        .environmentObject(CaravanManager())
}

