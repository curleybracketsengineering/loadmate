import SwiftUI

/// Item library screen for managing reusable items
/// Swipe actions for edit/delete as per specification
struct LibraryView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    @State private var showingAddItem = false
    @State private var itemToEdit: Item?
    @State private var searchText = ""
    
    var filteredItems: [Item] {
        if searchText.isEmpty {
            return caravanManager.libraryItems
        }
        return caravanManager.libraryItems.filter {
            $0.name.localizedCaseInsensitiveContains(searchText)
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                Theme.Colors.background
                    .ignoresSafeArea()
                
                if caravanManager.libraryItems.isEmpty {
                    EmptyLibraryView(showingAddItem: $showingAddItem)
                } else {
                    List {
                        ForEach(filteredItems) { item in
                            LibraryItemRow(item: item)
                                .listRowBackground(Theme.Colors.card)
                                .listRowSeparatorTint(Theme.Colors.muted.opacity(0.3))
                                .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                    Button(role: .destructive) {
                                        caravanManager.deleteItem(item)
                                    } label: {
                                        Label("Delete", systemImage: "trash")
                                    }
                                }
                                .swipeActions(edge: .leading, allowsFullSwipe: false) {
                                    Button {
                                        itemToEdit = item
                                    } label: {
                                        Label("Edit", systemImage: "pencil")
                                    }
                                    .tint(Theme.Colors.primary)
                                }
                        }
                    }
                    .listStyle(.plain)
                    .scrollContentBackground(.hidden)
                }
            }
            .searchable(text: $searchText, prompt: "Search items...")
            .navigationTitle("Item Library")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(Theme.Colors.background, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        showingAddItem = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                    }
                }
            }
            .sheet(isPresented: $showingAddItem) {
                ItemFormView(mode: .add)
            }
            .sheet(item: $itemToEdit) { item in
                ItemFormView(mode: .edit(item))
            }
        }
    }
}

// MARK: - Library Item Row

struct LibraryItemRow: View {
    @EnvironmentObject var caravanManager: CaravanManager
    let item: Item
    
    var isLoaded: Bool {
        caravanManager.isItemLoaded(item)
    }
    
    var body: some View {
        HStack(spacing: Theme.Spacing.md) {
            // Category Icon
            if let category = item.category {
                Image(systemName: category.icon)
                    .font(.title2)
                    .foregroundStyle(Theme.Colors.primary)
                    .frame(width: 40)
            } else {
                Image(systemName: "shippingbox")
                    .font(.title2)
                    .foregroundStyle(Theme.Colors.muted)
                    .frame(width: 40)
            }
            
            // Item Details
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Text(item.name)
                        .font(.headline)
                        .foregroundStyle(Theme.Colors.text)
                    
                    if isLoaded {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(Theme.Colors.success)
                            .font(.caption)
                    }
                }
                
                HStack(spacing: Theme.Spacing.sm) {
                    Text(String(format: "%.1f kg", item.weight))
                        .font(.subheadline)
                        .foregroundStyle(Theme.Colors.muted)
                    
                    if let zone = item.defaultZone {
                        Text("• \(zone.shortName)")
                            .font(.caption)
                            .foregroundStyle(Theme.Colors.muted)
                    }
                }
            }
            
            Spacer()
            
            // Weight badge
            Text(String(format: "%.1f kg", item.weight))
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundStyle(Theme.Colors.text)
                .padding(.horizontal, Theme.Spacing.sm)
                .padding(.vertical, Theme.Spacing.xs)
                .background(Theme.Colors.background)
                .clipShape(RoundedRectangle(cornerRadius: 6))
        }
        .padding(.vertical, Theme.Spacing.xs)
    }
}

// MARK: - Empty Library View

struct EmptyLibraryView: View {
    @Binding var showingAddItem: Bool

    var body: some View {
        VStack(spacing: Theme.Spacing.lg) {
            Image(systemName: "books.vertical")
                .font(.system(size: 60))
                .foregroundStyle(Theme.Colors.muted)

            Text("No Items Yet")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundStyle(Theme.Colors.text)

            Text("Add items to your library to start tracking what you load in your caravan.")
                .font(.subheadline)
                .foregroundStyle(Theme.Colors.muted)
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            Button {
                showingAddItem = true
            } label: {
                Label("Add Your First Item", systemImage: "plus")
                    .font(.headline)
                    .padding()
                    .background(Theme.Colors.primary)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))
            }
        }
    }
}

#Preview {
    LibraryView()
        .environmentObject(CaravanManager())
}

