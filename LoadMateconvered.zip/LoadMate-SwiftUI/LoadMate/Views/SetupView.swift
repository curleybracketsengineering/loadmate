import SwiftUI

/// Setup/Settings screen for caravan configuration
/// Includes base weight, MTPLM, tow ball weight, and zone factors
struct SetupView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    @State private var showingZoneFactors = false
    @State private var showingDisclaimer = false
    
    var body: some View {
        NavigationStack {
            Form {
                // Caravan Weights Section
                Section {
                    WeightInputRow(
                        label: "Base Weight (Empty)",
                        value: $caravanManager.config.baseWeight,
                        unit: "kg"
                    )
                    
                    WeightInputRow(
                        label: "MTPLM",
                        value: $caravanManager.config.mtplm,
                        unit: "kg"
                    )
                } header: {
                    Text("Caravan Weights")
                } footer: {
                    Text("Base weight is the measured empty caravan weight. MTPLM is the Maximum Technically Permissible Laden Mass.")
                }
                
                // Tow Vehicle Section
                Section {
                    WeightInputRow(
                        label: "Max Tow Ball Weight",
                        value: $caravanManager.config.carMaxTowBallWeight,
                        unit: "kg"
                    )
                } header: {
                    Text("Tow Vehicle")
                } footer: {
                    Text("The maximum tow ball weight your vehicle can handle. Check your vehicle handbook.")
                }
                
                // Nose Weight Settings
                Section {
                    PercentageRow(
                        label: "Base Nose Weight",
                        value: $caravanManager.config.baseNoseWeightPercentage
                    )
                    
                    PercentageRow(
                        label: "Min Recommended",
                        value: $caravanManager.config.minNoseWeightPercentage
                    )
                    
                    PercentageRow(
                        label: "Max Recommended",
                        value: $caravanManager.config.maxNoseWeightPercentage
                    )
                } header: {
                    Text("Nose Weight Percentages")
                } footer: {
                    Text("Industry standard is 5-7% of total weight. Base is typically 6%.")
                }
                
                // Zone Factors
                Section {
                    NavigationLink {
                        ZoneFactorsView()
                    } label: {
                        HStack {
                            Text("Zone Factors")
                            Spacer()
                            Text("Advanced")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                } header: {
                    Text("Advanced Settings")
                } footer: {
                    Text("Adjust how each loading zone affects nose weight calculation.")
                }
                
                // About Section
                Section {
                    Button {
                        showingDisclaimer = true
                    } label: {
                        Label("View Disclaimer", systemImage: "exclamationmark.triangle")
                    }
                    
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("About")
                }
            }
            .navigationTitle("Setup")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $showingDisclaimer) {
                DisclaimerView(hasAcceptedDisclaimer: .constant(true))
            }
        }
    }
}

// MARK: - Weight Input Row

struct WeightInputRow: View {
    let label: String
    @Binding var value: Double
    let unit: String
    
    @State private var textValue: String = ""
    @FocusState private var isFocused: Bool
    
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            TextField("0", text: $textValue)
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .frame(width: 80)
                .focused($isFocused)
                .onChange(of: textValue) { _, newValue in
                    if let num = Double(newValue) {
                        value = num
                    }
                }
            Text(unit)
                .foregroundStyle(.secondary)
        }
        .onAppear {
            textValue = value > 0 ? String(format: "%.0f", value) : ""
        }
    }
}

// MARK: - Percentage Row

struct PercentageRow: View {
    let label: String
    @Binding var value: Double
    
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            Text(String(format: "%.0f%%", value * 100))
                .foregroundStyle(.secondary)
            Stepper("", value: $value, in: 0.01...0.20, step: 0.01)
                .labelsHidden()
        }
    }
}

#Preview {
    SetupView()
        .environmentObject(CaravanManager())
}

