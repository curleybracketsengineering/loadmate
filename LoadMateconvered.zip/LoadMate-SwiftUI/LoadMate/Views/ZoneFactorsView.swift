import SwiftUI

/// Advanced settings for zone impact factors
/// Allows users to customize how each zone affects nose weight
struct ZoneFactorsView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    
    var body: some View {
        Form {
            Section {
                ForEach(LocationZone.allCases) { zone in
                    ZoneFactorRow(zone: zone)
                }
            } header: {
                Text("Zone Impact Factors")
            } footer: {
                Text("Positive values increase nose weight, negative values decrease it. Values represent the percentage of item weight that affects nose weight.")
            }
            
            Section {
                Button("Reset to Defaults") {
                    resetToDefaults()
                }
                .foregroundStyle(Theme.Colors.danger)
            }
            
            // Explanation Section
            Section {
                VStack(alignment: .leading, spacing: Theme.Spacing.md) {
                    ZoneExplanationRow(zone: .frontLocker, description: "Items at the very front heavily increase nose weight")
                    ZoneExplanationRow(zone: .front, description: "Items forward of axle moderately increase nose weight")
                    ZoneExplanationRow(zone: .middle, description: "Items over the axle have minimal impact")
                    ZoneExplanationRow(zone: .rear, description: "Items behind axle reduce nose weight")
                    ZoneExplanationRow(zone: .bikeRack, description: "Items at rear extreme significantly reduce nose weight")
                }
            } header: {
                Text("Understanding Zones")
            }
        }
        .navigationTitle("Zone Factors")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    private func resetToDefaults() {
        for zone in LocationZone.allCases {
            caravanManager.config.zoneFactors[zone] = zone.defaultFactor
        }
    }
}

// MARK: - Zone Factor Row

struct ZoneFactorRow: View {
    @EnvironmentObject var caravanManager: CaravanManager
    let zone: LocationZone
    
    var factor: Binding<Double> {
        Binding(
            get: { caravanManager.config.factor(for: zone) },
            set: { caravanManager.config.zoneFactors[zone] = $0 }
        )
    }
    
    var body: some View {
        HStack {
            Image(systemName: zone.icon)
                .foregroundStyle(Theme.Colors.primary)
                .frame(width: 30)
            
            VStack(alignment: .leading) {
                Text(zone.rawValue)
                    .font(.subheadline)
                Text("Default: \(String(format: "%+.0f%%", zone.defaultFactor * 100))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            
            Spacer()
            
            Text(String(format: "%+.0f%%", factor.wrappedValue * 100))
                .font(.headline)
                .foregroundStyle(factor.wrappedValue >= 0 ? Theme.Colors.success : Theme.Colors.danger)
                .frame(width: 50)
            
            Stepper("", value: factor, in: -0.50...0.50, step: 0.05)
                .labelsHidden()
        }
    }
}

// MARK: - Zone Explanation Row

struct ZoneExplanationRow: View {
    let zone: LocationZone
    let description: String
    
    var body: some View {
        HStack(alignment: .top, spacing: Theme.Spacing.md) {
            Image(systemName: zone.icon)
                .foregroundStyle(Theme.Colors.primary)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(zone.shortName)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                Text(description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

#Preview {
    NavigationStack {
        ZoneFactorsView()
    }
    .environmentObject(CaravanManager())
}

