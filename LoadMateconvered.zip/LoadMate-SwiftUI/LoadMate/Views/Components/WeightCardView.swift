import SwiftUI

/// Main weight display card ported from React Native WeightCard component
/// Shows current weight, progress bar, and nose weight calculations
struct WeightCardView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    
    var body: some View {
        VStack(spacing: Theme.Spacing.lg) {
            // Status Badge
            StatusBadgeView(status: caravanManager.weightStatus)
            
            // Weight Card
            VStack(spacing: Theme.Spacing.lg) {
                // Weight Display Section
                WeightDisplaySection(
                    currentWeight: caravanManager.currentWeight,
                    mtplm: caravanManager.config.mtplm,
                    availableWeight: caravanManager.availableWeight,
                    weightPercentage: caravanManager.weightPercentage,
                    statusColor: caravanManager.weightStatus.color
                )
                
                Divider()
                
                // Nose Weight Section
                NoseWeightSection(
                    baseNoseWeight: caravanManager.baseNoseWeight,
                    noseWeightImpact: caravanManager.noseWeightImpact,
                    calculatedNoseWeight: caravanManager.calculatedNoseWeight,
                    towBallWeightMin: caravanManager.towBallWeightMin,
                    towBallWeightMax: caravanManager.towBallWeightMax,
                    carMaxTowBallWeight: caravanManager.config.carMaxTowBallWeight,
                    isTowBallWeightSafe: caravanManager.isTowBallWeightSafe
                )
            }
            .padding(Theme.Spacing.xl)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.lg))
            .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 2)
        }
    }
}

// MARK: - Status Badge

struct StatusBadgeView: View {
    let status: WeightStatus
    
    var body: some View {
        HStack(spacing: Theme.Spacing.sm) {
            if status.showWarningIcon {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.title3)
            }
            Text(status.text)
                .font(.headline)
                .fontWeight(.bold)
        }
        .foregroundStyle(.white)
        .padding(.vertical, Theme.Spacing.md)
        .frame(maxWidth: .infinity)
        .background(status.color)
        .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))
    }
}

// MARK: - Weight Display Section

struct WeightDisplaySection: View {
    let currentWeight: Double
    let mtplm: Double
    let availableWeight: Double
    let weightPercentage: Double
    let statusColor: Color
    
    var body: some View {
        VStack(spacing: Theme.Spacing.md) {
            // Current Weight Row
            HStack {
                Text("Current Weight")
                    .font(.subheadline)
                    .foregroundStyle(Theme.Colors.textSecondary)
                Spacer()
                Text(String(format: "%.1f kg", currentWeight))
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(statusColor)
            }
            
            // Progress Bar
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 6)
                        .fill(Color.gray.opacity(0.2))
                    
                    RoundedRectangle(cornerRadius: 6)
                        .fill(statusColor)
                        .frame(width: geo.size.width * min(weightPercentage / 100, 1))
                }
            }
            .frame(height: 12)
            
            // MTPLM and Available Weight Row
            HStack {
                Text("MTPLM: \(Int(mtplm)) kg")
                    .font(.caption)
                    .foregroundStyle(Theme.Colors.textSecondary)
                Spacer()
                Text("\(availableWeight >= 0 ? "Available" : "Over"): \(String(format: "%.1f", abs(availableWeight))) kg")
                    .font(.caption)
                    .foregroundStyle(availableWeight < 0 ? Theme.Colors.danger : Theme.Colors.success)
            }
        }
    }
}

// MARK: - Nose Weight Section

struct NoseWeightSection: View {
    let baseNoseWeight: Double
    let noseWeightImpact: Double
    let calculatedNoseWeight: Double
    let towBallWeightMin: Double
    let towBallWeightMax: Double
    let carMaxTowBallWeight: Double
    let isTowBallWeightSafe: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: Theme.Spacing.md) {
            Text("Nose Weight")
                .font(.headline)
                .foregroundStyle(Theme.Colors.textDark)
            
            // Nose Weight Breakdown Card
            VStack(spacing: Theme.Spacing.sm) {
                NoseWeightRow(label: "Base (6%)", value: baseNoseWeight, isBold: false)
                NoseWeightRow(
                    label: "Location Impact",
                    value: noseWeightImpact,
                    isBold: false,
                    showSign: true,
                    valueColor: noseWeightImpact >= 0 ? Theme.Colors.success : Theme.Colors.danger
                )
                Divider()
                NoseWeightRow(
                    label: "Calculated Nose Weight",
                    value: calculatedNoseWeight,
                    isBold: true,
                    valueColor: Theme.Colors.primary,
                    valueFont: .title2
                )
            }
            .padding()
            .background(Theme.Colors.lightBackground)
            .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))

            // Min/Max Range
            HStack {
                VStack {
                    Text("Min (5%)")
                        .font(.caption)
                        .foregroundStyle(Theme.Colors.textSecondary)
                    Text(String(format: "%.1f kg", towBallWeightMin))
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundStyle(Theme.Colors.textDark)
                }
                .frame(maxWidth: .infinity)

                Divider()
                    .frame(height: 40)

                VStack {
                    Text("Max (7%)")
                        .font(.caption)
                        .foregroundStyle(Theme.Colors.textSecondary)
                    Text(String(format: "%.1f kg", towBallWeightMax))
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundStyle(Theme.Colors.textDark)
                }
                .frame(maxWidth: .infinity)
            }
            .padding()
            .background(Theme.Colors.lightBackground)
            .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))

            // Car Max Tow Ball Warning
            if carMaxTowBallWeight > 0 {
                HStack {
                    Text("Car Max Tow Ball: \(Int(carMaxTowBallWeight)) kg")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundStyle(isTowBallWeightSafe ? Theme.Colors.info : Theme.Colors.danger)

                    Spacer()

                    if !isTowBallWeightSafe {
                        HStack(spacing: 4) {
                            Image(systemName: "exclamationmark.triangle.fill")
                            Text("EXCEEDS CAR LIMIT")
                                .font(.caption)
                                .fontWeight(.bold)
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Theme.Colors.danger)
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                    }
                }
                .padding()
                .background(isTowBallWeightSafe ? Theme.Colors.lightBackground : Color(hex: "fef2f2"))
                .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))
            }
        }
    }
}

// MARK: - Nose Weight Row

struct NoseWeightRow: View {
    let label: String
    let value: Double
    var isBold: Bool = false
    var showSign: Bool = false
    var valueColor: Color = Theme.Colors.textDark
    var valueFont: Font = .subheadline

    var body: some View {
        HStack {
            Text(label)
                .font(isBold ? .subheadline.bold() : .subheadline)
                .foregroundStyle(isBold ? Theme.Colors.textDark : Theme.Colors.textSecondary)
            Spacer()
            Text(formatValue())
                .font(valueFont)
                .fontWeight(isBold ? .bold : .semibold)
                .foregroundStyle(valueColor)
        }
    }

    private func formatValue() -> String {
        if showSign {
            return String(format: "%@%.1f kg", value >= 0 ? "+" : "", value)
        }
        return String(format: "%.1f kg", value)
    }
}

#Preview {
    ScrollView {
        WeightCardView()
            .padding()
    }
    .background(Theme.Colors.background)
    .environmentObject(CaravanManager())
}

