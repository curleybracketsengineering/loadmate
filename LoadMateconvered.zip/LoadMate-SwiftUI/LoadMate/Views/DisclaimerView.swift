import SwiftUI

/// Safety disclaimer shown on first launch
/// User must accept before using the app
struct DisclaimerView: View {
    @Binding var hasAcceptedDisclaimer: Bool
    @State private var hasScrolledToBottom = false
    
    var body: some View {
        ZStack {
            Theme.Colors.background
                .ignoresSafeArea()
            
            VStack(spacing: Theme.Spacing.xl) {
                // Header
                VStack(spacing: Theme.Spacing.md) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 60))
                        .foregroundStyle(Theme.Colors.warning)
                    
                    Text("Important Safety Notice")
                        .font(.title.bold())
                        .foregroundStyle(Theme.Colors.text)
                }
                .padding(.top, Theme.Spacing.xxl)
                
                // Disclaimer content
                ScrollView {
                    VStack(alignment: .leading, spacing: Theme.Spacing.lg) {
                        DisclaimerSection(
                            icon: "gauge.with.dots.needle.bottom.50percent",
                            title: "Estimation Tool Only",
                            content: "LoadMate provides ESTIMATES only. All calculations are approximations based on the data you enter and standard assumptions."
                        )
                        
                        DisclaimerSection(
                            icon: "scalemass",
                            title: "Always Measure",
                            content: "You MUST physically measure your actual nose weight using calibrated scales before every journey. Never rely solely on this app."
                        )
                        
                        DisclaimerSection(
                            icon: "exclamationmark.shield",
                            title: "Legal Compliance",
                            content: "Do not exceed your caravan's MTPLM or your vehicle's maximum tow ball weight. These are legal limits that must be observed."
                        )
                        
                        DisclaimerSection(
                            icon: "hand.raised",
                            title: "No Liability",
                            content: "The developers accept no liability for incorrect loading, overweight vehicles, or any damage or injury resulting from use of this application."
                        )
                        
                        DisclaimerSection(
                            icon: "checkmark.circle",
                            title: "Your Responsibility",
                            content: "Safe loading is YOUR responsibility. This app is a planning aid only - you must verify all weights independently."
                        )
                    }
                    .padding(.horizontal)
                    
                    // Invisible marker to detect scroll
                    GeometryReader { geo in
                        Color.clear
                            .preference(key: ScrollOffsetKey.self, value: geo.frame(in: .named("scroll")).maxY)
                    }
                    .frame(height: 1)
                }
                .coordinateSpace(name: "scroll")
                .onPreferenceChange(ScrollOffsetKey.self) { maxY in
                    // Consider scrolled to bottom when near end
                    hasScrolledToBottom = maxY < 700
                }
                
                // Accept button
                VStack(spacing: Theme.Spacing.sm) {
                    Button {
                        withAnimation {
                            hasAcceptedDisclaimer = true
                        }
                    } label: {
                        Text("I Understand and Accept")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Theme.Colors.primary)
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))
                    }
                    
                    Text("By continuing, you acknowledge that this is an estimation tool only")
                        .font(.caption)
                        .foregroundStyle(Theme.Colors.muted)
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal)
                .padding(.bottom, Theme.Spacing.xl)
            }
        }
    }
}

// MARK: - Disclaimer Section Component

struct DisclaimerSection: View {
    let icon: String
    let title: String
    let content: String
    
    var body: some View {
        HStack(alignment: .top, spacing: Theme.Spacing.md) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(Theme.Colors.warning)
                .frame(width: 30)
            
            VStack(alignment: .leading, spacing: Theme.Spacing.xs) {
                Text(title)
                    .font(.headline)
                    .foregroundStyle(Theme.Colors.text)
                
                Text(content)
                    .font(.subheadline)
                    .foregroundStyle(Theme.Colors.muted)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.Colors.card)
        .clipShape(RoundedRectangle(cornerRadius: Theme.CornerRadius.md))
    }
}

// MARK: - Scroll Offset Preference Key

struct ScrollOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

#Preview {
    DisclaimerView(hasAcceptedDisclaimer: .constant(false))
}

