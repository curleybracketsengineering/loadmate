import SwiftUI

/// Load/Unload screen with swipe interactions
/// Swipe RIGHT to load, Swipe LEFT to unload as per specification
struct LoadView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    @State private var selectedTab = 0
    
    var body: some View {
        NavigationStack {
            ZStack {
                Theme.Colors.background
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Segmented Control
                    Picker("View", selection: $selectedTab) {
                        Text("Available").tag(0)
                        Text("Loaded").tag(1)
                    }
                    .pickerStyle(.segmented)
                    .padding()
                    
                    // Content based on selection
                    if selectedTab == 0 {
                        AvailableItemsListView()
                    } else {
                        LoadedItemsListView()
                    }
                }
            }
            .navigationTitle("Load Items")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(Theme.Colors.background, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
        }
    }
}

// MARK: - Available Items List (to load)

struct AvailableItemsListView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    @State private var itemToLoad: Item?
    
    var availableItems: [Item] {
        caravanManager.libraryItems.filter { !caravanManager.isItemLoaded($0) }
    }
    
    var body: some View {
        if availableItems.isEmpty {
            VStack(spacing: Theme.Spacing.lg) {
                Image(systemName: "checkmark.circle")
                    .font(.system(size: 60))
                    .foregroundStyle(Theme.Colors.success)
                
                Text("All Items Loaded")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(Theme.Colors.text)
                
                Text("All items from your library are currently loaded.")
                    .font(.subheadline)
                    .foregroundStyle(Theme.Colors.muted)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            List {
                ForEach(availableItems) { item in
                    LoadableItemRow(item: item)
                        .listRowBackground(Theme.Colors.card)
                        .listRowSeparatorTint(Theme.Colors.muted.opacity(0.3))
                        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                            Button {
                                itemToLoad = item
                            } label: {
                                Label("Load", systemImage: "plus.circle.fill")
                            }
                            .tint(Theme.Colors.success)
                        }
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .sheet(item: $itemToLoad) { item in
                LoadItemSheet(item: item)
            }
        }
    }
}

// MARK: - Loadable Item Row

struct LoadableItemRow: View {
    let item: Item
    
    var body: some View {
        HStack(spacing: Theme.Spacing.md) {
            if let category = item.category {
                Image(systemName: category.icon)
                    .font(.title2)
                    .foregroundStyle(Theme.Colors.primary)
                    .frame(width: 40)
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .font(.headline)
                    .foregroundStyle(Theme.Colors.text)
                
                if let zone = item.defaultZone {
                    Text("Default: \(zone.shortName)")
                        .font(.caption)
                        .foregroundStyle(Theme.Colors.muted)
                }
            }
            
            Spacer()
            
            VStack(alignment: .trailing) {
                Text(String(format: "%.1f kg", item.weight))
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundStyle(Theme.Colors.text)
                
                Image(systemName: "chevron.left")
                    .font(.caption)
                    .foregroundStyle(Theme.Colors.success)
            }
        }
        .padding(.vertical, Theme.Spacing.xs)
    }
}

// MARK: - Load Item Sheet

struct LoadItemSheet: View {
    @EnvironmentObject var caravanManager: CaravanManager
    @Environment(\.dismiss) private var dismiss
    
    let item: Item
    @State private var quantity: Int = 1
    @State private var zone: LocationZone
    
    init(item: Item) {
        self.item = item
        _zone = State(initialValue: item.defaultZone ?? .middle)
    }
    
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Text(item.name)
                            .font(.headline)
                        Spacer()
                        Text(String(format: "%.1f kg", item.weight))
                            .foregroundStyle(.secondary)
                    }
                }

                Section {
                    Stepper("Quantity: \(quantity)", value: $quantity, in: 1...99)

                    HStack {
                        Text("Total Weight")
                        Spacer()
                        Text(String(format: "%.1f kg", item.weight * Double(quantity)))
                            .fontWeight(.semibold)
                    }
                }

                Section {
                    Picker("Loading Zone", selection: $zone) {
                        ForEach(LocationZone.allCases) { z in
                            Label(z.rawValue, systemImage: z.icon)
                                .tag(z)
                        }
                    }
                    .pickerStyle(.navigationLink)
                } footer: {
                    Text("Zone affects nose weight calculation")
                }
            }
            .navigationTitle("Load Item")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Load") {
                        caravanManager.loadItem(item, quantity: quantity, zone: zone)
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Loaded Items List

struct LoadedItemsListView: View {
    @EnvironmentObject var caravanManager: CaravanManager

    var body: some View {
        if caravanManager.loadedItems.isEmpty {
            VStack(spacing: Theme.Spacing.lg) {
                Image(systemName: "shippingbox")
                    .font(.system(size: 60))
                    .foregroundStyle(Theme.Colors.muted)

                Text("Nothing Loaded")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundStyle(Theme.Colors.text)

                Text("Swipe right on items in the 'Available' tab to load them.")
                    .font(.subheadline)
                    .foregroundStyle(Theme.Colors.muted)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            List {
                ForEach(caravanManager.loadedItems) { loadedItem in
                    LoadedItemRow(loadedItem: loadedItem)
                        .listRowBackground(Theme.Colors.card)
                        .listRowSeparatorTint(Theme.Colors.muted.opacity(0.3))
                        .swipeActions(edge: .leading, allowsFullSwipe: true) {
                            Button(role: .destructive) {
                                caravanManager.unloadItem(loadedItem)
                            } label: {
                                Label("Unload", systemImage: "minus.circle.fill")
                            }
                        }
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
        }
    }
}

// MARK: - Loaded Item Row

struct LoadedItemRow: View {
    let loadedItem: LoadedItem

    var body: some View {
        HStack(spacing: Theme.Spacing.md) {
            Image(systemName: loadedItem.zone.icon)
                .font(.title2)
                .foregroundStyle(Theme.Colors.success)
                .frame(width: 40)

            VStack(alignment: .leading, spacing: 2) {
                Text(loadedItem.item.name)
                    .font(.headline)
                    .foregroundStyle(Theme.Colors.text)

                HStack(spacing: Theme.Spacing.sm) {
                    Text(loadedItem.zone.shortName)
                        .font(.caption)
                        .foregroundStyle(Theme.Colors.muted)

                    if loadedItem.quantity > 1 {
                        Text("× \(loadedItem.quantity)")
                            .font(.caption)
                            .foregroundStyle(Theme.Colors.primary)
                    }
                }
            }

            Spacer()

            VStack(alignment: .trailing) {
                Text(String(format: "%.1f kg", loadedItem.totalWeight))
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundStyle(Theme.Colors.text)

                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundStyle(Theme.Colors.danger)
            }
        }
        .padding(.vertical, Theme.Spacing.xs)
    }
}

#Preview {
    LoadView()
        .environmentObject(CaravanManager())
}

