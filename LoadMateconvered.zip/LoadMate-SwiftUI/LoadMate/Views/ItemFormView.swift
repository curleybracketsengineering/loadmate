import SwiftUI

/// Form for adding or editing items in the library
struct ItemFormView: View {
    @EnvironmentObject var caravanManager: CaravanManager
    @Environment(\.dismiss) private var dismiss
    
    enum Mode: Identifiable {
        case add
        case edit(Item)
        
        var id: String {
            switch self {
            case .add: return "add"
            case .edit(let item): return item.id.uuidString
            }
        }
    }
    
    let mode: Mode
    
    @State private var name: String = ""
    @State private var weight: String = ""
    @State private var defaultZone: LocationZone = .middle
    @State private var category: ItemCategory = .other
    @State private var useDefaultZone: Bool = false
    
    private var isEditing: Bool {
        if case .edit = mode { return true }
        return false
    }
    
    private var title: String {
        isEditing ? "Edit Item" : "Add Item"
    }
    
    private var isValid: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        Double(weight) != nil &&
        (Double(weight) ?? 0) > 0
    }
    
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Item Name", text: $name)
                    
                    HStack {
                        TextField("Weight", text: $weight)
                            .keyboardType(.decimalPad)
                        Text("kg")
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("Item Details")
                }
                
                Section {
                    Picker("Category", selection: $category) {
                        ForEach(ItemCategory.allCases) { cat in
                            Label(cat.rawValue, systemImage: cat.icon)
                                .tag(cat)
                        }
                    }
                } header: {
                    Text("Category")
                }
                
                Section {
                    Toggle("Set Default Zone", isOn: $useDefaultZone)
                    
                    if useDefaultZone {
                        Picker("Default Zone", selection: $defaultZone) {
                            ForEach(LocationZone.allCases) { zone in
                                Label(zone.rawValue, systemImage: zone.icon)
                                    .tag(zone)
                            }
                        }
                        .pickerStyle(.navigationLink)
                    }
                } header: {
                    Text("Loading Zone")
                } footer: {
                    Text("Set a default zone to automatically assign items when loading.")
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button(isEditing ? "Save" : "Add") {
                        saveItem()
                        dismiss()
                    }
                    .disabled(!isValid)
                }
            }
            .onAppear {
                loadExistingItem()
            }
        }
    }
    
    private func loadExistingItem() {
        if case .edit(let item) = mode {
            name = item.name
            weight = String(format: "%.1f", item.weight)
            category = item.category ?? .other
            if let zone = item.defaultZone {
                defaultZone = zone
                useDefaultZone = true
            }
        }
    }
    
    private func saveItem() {
        guard let weightValue = Double(weight) else { return }
        
        let item = Item(
            id: existingItemId ?? UUID(),
            name: name.trimmingCharacters(in: .whitespaces),
            weight: weightValue,
            defaultZone: useDefaultZone ? defaultZone : nil,
            category: category
        )
        
        if isEditing {
            caravanManager.updateItem(item)
        } else {
            caravanManager.addItem(item)
        }
    }
    
    private var existingItemId: UUID? {
        if case .edit(let item) = mode {
            return item.id
        }
        return nil
    }
}

#Preview("Add") {
    ItemFormView(mode: .add)
        .environmentObject(CaravanManager())
}

#Preview("Edit") {
    ItemFormView(mode: .edit(Item(name: "Test Item", weight: 5.5, category: .camping)))
        .environmentObject(CaravanManager())
}

