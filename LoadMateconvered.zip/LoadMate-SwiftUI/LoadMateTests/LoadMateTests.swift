//
//  LoadMateTests.swift
//  LoadMateTests
//
//  Created by ChrisMatheson on 26/03/2026.
//

import Testing

struct LoadMateTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
